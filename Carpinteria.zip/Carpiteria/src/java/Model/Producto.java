/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author bryan
 */
public class Producto {
    private int id;
    private int categoria;
    private int empleado;
    private String nombre;
    private int cant;
    private double precio;

    public Producto() {
    }

    public Producto(int id, int categoria, int empleado, String nombre, int cant, double precio) {
        this.id = id;
        this.categoria = categoria;
        this.empleado = empleado;
        this.nombre = nombre;
        this.cant = cant;
        this.precio = precio;
    }
    
        public Producto(int categoria, int empleado, String nombre, int cant, double precio) {
        this.categoria = categoria;
        this.empleado = empleado;
        this.nombre = nombre;
        this.cant = cant;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getEmpleado() {
        return empleado;
    }

    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

}
