/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.List;

/**
 *
 * @author bryan
 */
public interface ICargoDAO {
     public List<Cargo> Listar();
     public Cargo getCargo (int id);
     public void Guardar(Cargo cargo);
     public void Insertar(Cargo cargo);
     public void Eliminar (int id);
}
