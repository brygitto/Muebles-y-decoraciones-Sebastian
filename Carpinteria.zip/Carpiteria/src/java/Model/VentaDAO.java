/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Setting.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bryan
 */
public class VentaDAO implements IVentaDAO{
    
        private Connection conn;

    public Connection getConnection() {
        if(conn==null){
            conn = new ConnectionDB().getConnection();
        }
        return conn;
    }

    public void setConnetion(Connection conn) {
        this.conn = conn;
    }
    
    public void CloseConnection(){
        try{
            getConnection().close();
            conn=null;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Venta> Listar() {
    List<Venta> lista= new ArrayList<Venta>();
        try{
        Statement st = getConnection().createStatement();
        ResultSet rs= st.executeQuery("SELECT * FROM venta");
        while(rs.next()){
            Venta venta = new Venta();
                venta.setId(rs.getInt("VentaID"));
                venta.setCliente(rs.getInt("ClienteVen"));
                venta.setProducto(rs.getInt("ProductoVen"));
                venta.setEmpleado(rs.getInt("EmpleadoVen"));
                venta.setCant(rs.getInt("Cant"));
                venta.setPrecio(rs.getDouble("Precio"));
        lista.add(venta);}
        } catch(Exception e){
                e.printStackTrace();
                }
        return lista;     
    }

    @Override
    public Venta getVenta(int id) {
                Venta venta = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM venta where VentaID = ? ");
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                venta = new Venta();
                venta.setId(rs.getInt("VentaID"));
                venta.setCliente(rs.getInt("ClienteVen"));
                venta.setProducto(rs.getInt("ProductoVen"));
                venta.setEmpleado(rs.getInt("EmpleadoVen"));
                venta.setCant(rs.getInt("Cant"));
                venta.setPrecio(rs.getInt("Precio"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return venta;
    }

    @Override
    public void Guardar(Venta venta) {
                try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE venta set ClienteVen="+venta.getCliente()+",ProductoVen="+venta.getProducto()+",EmpleadoVen="+venta.getEmpleado()+",Cant="+venta.getCant()+
                        ",Precio="+venta.getPrecio()+" Where VentaID="+venta.getId());
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void Insertar(Venta venta) {
                try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("INSERT INTO venta  VALUES ("+venta.getId()+","+venta.getCliente()+","+venta.getProducto()+","+venta.getEmpleado()+","+venta.getCant()+
                        ","+venta.getPrecio()+")");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void Eliminar(int id) {
                try {
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("DELETE FROM venta WHERE VentaID="+id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
