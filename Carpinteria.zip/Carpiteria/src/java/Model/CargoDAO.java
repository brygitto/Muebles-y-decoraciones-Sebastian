/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Setting.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bryan
 */
public class CargoDAO implements ICargoDAO{
    
        private Connection conn;

    public Connection getConnection() {
        if(conn==null){
            conn = new ConnectionDB().getConnection();
        }
        return conn;
    }

    public void setConnetion(Connection conn) {
        this.conn = conn;
    }
    
    public void CloseConnection(){
        try{
            getConnection().close();
            conn=null;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Cargo> Listar() {
        List<Cargo> lista= new ArrayList<Cargo>();
        try{
        Statement st = getConnection().createStatement();
        ResultSet rs= st.executeQuery("SELECT * FROM cargo");
        while(rs.next()){
            Cargo cargo = new Cargo();
                cargo.setId(rs.getInt("CargoID"));
                cargo.setNombre(rs.getString("Cargo_nom"));
                cargo.setDescripcion(rs.getString("Cargo_descripcion"));
        lista.add(cargo);}
        } catch(Exception e){
                e.printStackTrace();
                }
        return lista;  
    }

    @Override
    public Cargo getCargo(int id) {
        Cargo cargo = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM cargo where CargoID = ? ");
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                cargo = new Cargo();
                cargo.setId(rs.getInt("CargoID"));
                cargo.setNombre(rs.getString("Cargo_nom"));
                cargo.setDescripcion(rs.getString("Cargo_descripcion"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cargo;
    }

    @Override
    public void Guardar(Cargo cargo) {
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE cargo set Cargo_nom='"+cargo.getNombre()+"',Cargo_descripcion='"+cargo.getDescripcion()+
                        "' Where CargoID="+cargo.getId());
        }
        catch(Exception e){
            e.printStackTrace();
        }    
    }

    @Override
    public void Insertar(Cargo cargo) {
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("INSERT INTO cargo  VALUES ("+cargo.getId()+",'"+cargo.getNombre()+"','"+cargo.getDescripcion()+"')");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void Eliminar(int id) {
        try {
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("DELETE FROM cargo WHERE CargoID="+id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
