/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Setting.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bryan
 */
public class ClienteDAO implements IClienteDAO{
    private Connection conn;

    public Connection getConnection() {
        if(conn==null){
            conn = new ConnectionDB().getConnection();
        }
        return conn;
    }

    public void setConnetion(Connection conn) {
        this.conn = conn;
    }
    
    public void CloseConnection(){
        try{
            getConnection().close();
            conn=null;
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @Override
    public List<Cliente> Listar(){
        List<Cliente> lista= new ArrayList<Cliente>();
        try{
        Statement st = getConnection().createStatement();
        ResultSet rs= st.executeQuery("SELECT * FROM cliente");
        while(rs.next()){
            Cliente cliente = new Cliente();
                cliente.setId(rs.getInt("ClienteID"));
                cliente.setCc(rs.getInt("Cliente_Cc"));
                cliente.setNombre(rs.getString("Cliente_nom"));
                cliente.setApellido(rs.getString("Cliente_ape"));
                cliente.setDireccion(rs.getString("Cliente_direc"));
                cliente.setCorreo(rs.getString("Cliente_correo"));
                cliente.setCel(rs.getInt("Cliente_cel"));
        lista.add(cliente);}
        } catch(Exception e){
                e.printStackTrace();
                }
        return lista; 
}
        public Cliente getCliente(int cc) {
        Cliente cliente = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM cliente where Cliente_Cc = ? ");
            stm.setInt(1, cc);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                cliente = new Cliente();
                cliente.setId(rs.getInt("ClienteID"));
                cliente.setCc(rs.getInt("Cliente_Cc"));
                cliente.setNombre(rs.getString("Cliente_nom"));
                cliente.setApellido(rs.getString("Cliente_ape"));
                cliente.setDireccion(rs.getString("Cliente_direc"));
                cliente.setCorreo(rs.getString("Cliente_correo"));
                cliente.setCel(rs.getInt("Cliente_cel"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cliente;
    }
        
public Cliente getClienteId(int id) {
        Cliente cliente = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM cliente where ClienteID = ? ");
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                cliente = new Cliente();
                cliente.setId(rs.getInt("ClienteID"));
                cliente.setCc(rs.getInt("Cliente_Cc"));
                cliente.setNombre(rs.getString("Cliente_nom"));
                cliente.setApellido(rs.getString("Cliente_ape"));
                cliente.setDireccion(rs.getString("Cliente_direc"));
                cliente.setCorreo(rs.getString("Cliente_correo"));
                cliente.setCel(rs.getInt("Cliente_cel"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cliente;
    }
    @Override
    public void Guardar(Cliente cliente) {
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE cliente set Cliente_nom='"+cliente.getNombre()+"',Cliente_ape='"+cliente.getApellido()+"',Cliente_direc='"+cliente.getDireccion()+"',Cliente_correo='"+cliente.getCorreo()+
                        "',Cliente_cel="+cliente.getCel()+" Where Cliente_Cc="+cliente.getCc());
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @Override
    public void Insertar(Cliente cliente) {
        
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("INSERT INTO cliente  VALUES ("+cliente.getId()+","+cliente.getCc()+",'"+cliente.getNombre()+"','"+cliente.getApellido()+"','"+cliente.getDireccion()+"','"+cliente.getCorreo()+
                        "',"+cliente.getCel()+")");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
    
        @Override
    public void Eliminar(int cc) {
        
        try {
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("DELETE FROM cliente WHERE Cliente_Cc="+cc);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
