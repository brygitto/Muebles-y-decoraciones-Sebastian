/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.List;

/**
 *
 * @author bryan
 */
public interface IProductoDAO {
     public List<Producto> Listar();
     public Producto getProducto (int id);
     public void Guardar(Producto producto);
     public void Insertar(Producto producto);
     public void Eliminar (int id);
     public void CompraProducto(Producto producto, int cant);
}
