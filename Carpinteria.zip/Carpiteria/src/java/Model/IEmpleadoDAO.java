/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.List;

/**
 *
 * @author bryan
 */
public interface IEmpleadoDAO {
     public List<Empleado> Listar();
     public Empleado getEmpleado (int cc);
     public Empleado getEmpleadoid(int id);
     public Empleado getEmpleadoUsarioClave (String usuario, String clave);
     public void Guardar(Empleado empleado);
     public void Insertar(Empleado empleado);
     public void Eliminar (int id);
}
