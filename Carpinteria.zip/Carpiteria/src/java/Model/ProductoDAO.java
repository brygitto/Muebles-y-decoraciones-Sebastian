/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Setting.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bryan
 */
public class ProductoDAO implements IProductoDAO{

        private Connection conn;

    public Connection getConnection() {
        if(conn==null){
            conn = new ConnectionDB().getConnection();
        }
        return conn;
    }

    public void setConnetion(Connection conn) {
        this.conn = conn;
    }
    
    public void CloseConnection(){
        try{
            getConnection().close();
            conn=null;
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @Override
    public List<Producto> Listar() {
        List<Producto> lista= new ArrayList<Producto>();
        try{
        Statement st = getConnection().createStatement();
        ResultSet rs= st.executeQuery("SELECT * FROM producto");
        while(rs.next()){
            Producto producto = new Producto();
                producto.setId(rs.getInt("ProductoID"));
                producto.setCategoria(rs.getInt("Categoria_pro"));
                producto.setEmpleado(rs.getInt("Empleado_pro"));
                producto.setNombre(rs.getString("Producto_nom"));
                producto.setCant(rs.getInt("Producto_cant"));
                producto.setPrecio(rs.getDouble("Producto_pre"));
        lista.add(producto);}
        } catch(Exception e){
                e.printStackTrace();
                }
        return lista; 

    }  
    
    @Override
    public Producto getProducto(int id) {
        Producto producto = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM producto where ProductoID = ? ");
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                producto = new Producto();
                producto.setId(rs.getInt("ProductoID"));
                producto.setCategoria(rs.getInt("Categoria_pro"));
                producto.setEmpleado(rs.getInt("Empleado_pro"));
                producto.setNombre(rs.getString("Producto_nom"));
                producto.setCant(rs.getInt("Producto_cant"));
                producto.setPrecio(rs.getDouble("Producto_pre"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return producto;
    }

    @Override
    public void Guardar(Producto producto) {
        
            try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE producto set Categoria_pro="+producto.getCategoria()+",Empleado_pro="+producto.getEmpleado()+",Producto_nom='"+producto.getNombre()+"',Producto_pre="+producto.getPrecio()+
                        ",Producto_cant="+producto.getCant()+" Where ProductoID="+producto.getId());
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void Insertar(Producto producto) {
            
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("INSERT INTO producto  VALUES ("+producto.getId()+","+producto.getCategoria()+","+producto.getEmpleado()+",'"+producto.getNombre()+"',"+producto.getPrecio()+
                        ","+producto.getCant()+")");
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void Eliminar(int id) {
     
        try {
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("DELETE FROM producto WHERE ProductoID="+id);
        } catch (Exception e) {
            e.printStackTrace();
        }   }

    @Override
    public void CompraProducto(Producto producto, int cant) {
               try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE producto set Producto_cant="+(producto.getCant()-cant)+
                        " Where ProductoID="+producto.getId());
        }
        catch(Exception e){
            e.printStackTrace();
        } 

    }
    
}
