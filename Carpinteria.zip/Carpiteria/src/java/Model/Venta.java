/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author bryan
 */
public class Venta {
    private int id;
    private int cliente;
    private int empleado;
    private int producto;
    private int cant;
    private double precio;

    public Venta() {
    }

    public Venta(int id, int cliente, int empleado, int producto, int cant, double precio) {
        this.id = id;
        this.cliente = cliente;
        this.empleado = empleado;
        this.producto = producto;
        this.cant = cant;
        this.precio = precio;
    }
    
        public Venta(int cliente, int empleado, int producto, int cant, double precio) {
        this.cliente = cliente;
        this.empleado = empleado;
        this.producto = producto;
        this.cant = cant;
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }

    public int getEmpleado() {
        return empleado;
    }

    public void setEmpleado(int empleado) {
        this.empleado = empleado;
    }

    public int getProducto() {
        return producto;
    }

    public void setProducto(int producto) {
        this.producto = producto;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

}
