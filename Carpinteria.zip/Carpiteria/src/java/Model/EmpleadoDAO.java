/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Setting.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bryan
 */
public class EmpleadoDAO implements IEmpleadoDAO{
    
        private Connection conn;

    public Connection getConnection() {
        if(conn==null){
            conn = new ConnectionDB().getConnection();
        }
        return conn;
    }

    public void setConnetion(Connection conn) {
        this.conn = conn;
    }
    
    public void CloseConnection(){
        try{
            getConnection().close();
            conn=null;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Empleado> Listar() {
        List<Empleado> lista= new ArrayList<Empleado>();
        try{
        Statement st = getConnection().createStatement();
        ResultSet rs= st.executeQuery("SELECT * FROM empleado");
        while(rs.next()){
            Empleado empleado = new Empleado();
                empleado.setId(rs.getInt("EmpleadoID"));
                empleado.setCargo(rs.getInt("CargoEmpleado"));
                empleado.setCc(rs.getInt("Empleado_Cc"));
                empleado.setNombre(rs.getString("Empleado_nom"));
                empleado.setApellido(rs.getString("Empleado_ape"));
                empleado.setDireccion(rs.getString("Empleado_direc"));
                empleado.setCel(rs.getInt("Empleado_cel"));
                empleado.setUsuario(rs.getString("Usuario"));
                empleado.setClave(rs.getString("Clave"));
        lista.add(empleado);}
        } catch(Exception e){
                e.printStackTrace();
                }
        return lista;
    }

        @Override
    public Empleado getEmpleado(int cc) {
        Empleado empleado = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM empleado where Empleado_Cc = ? ");
            stm.setInt(1, cc);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                empleado = new Empleado();
                empleado.setId(rs.getInt("EmpleadoID"));
                empleado.setCc(rs.getInt("Empleado_Cc"));
                empleado.setNombre(rs.getString("Empleado_nom"));
                empleado.setApellido(rs.getString("Empleado_ape"));
                empleado.setDireccion(rs.getString("Empleado_direc"));
                empleado.setCargo(rs.getInt("CargoEmpleado"));
                empleado.setCel(rs.getInt("Empleado_cel"));
                empleado.setUsuario(rs.getString("Usuario"));
                empleado.setClave(rs.getString("Clave"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return empleado;
    
    }

    
    
    @Override
    public Empleado getEmpleadoid(int id) {
        Empleado empleado = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM empleado where EmpleadoID = ? ");
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                empleado = new Empleado();
                empleado.setId(rs.getInt("EmpleadoID"));
                empleado.setCc(rs.getInt("Empleado_Cc"));
                empleado.setNombre(rs.getString("Empleado_nom"));
                empleado.setApellido(rs.getString("Empleado_ape"));
                empleado.setDireccion(rs.getString("Empleado_direc"));
                empleado.setCargo(rs.getInt("CargoEmpleado"));
                empleado.setCel(rs.getInt("Empleado_cel"));
                empleado.setUsuario(rs.getString("Usuario"));
                empleado.setClave(rs.getString("Clave"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return empleado;
    
    }

    @Override
    public void Guardar(Empleado empleado) {
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE empleado set Empleado_nom='"+empleado.getNombre()+"',Empleado_ape='"+empleado.getApellido()+"',Empleado_direc='"+empleado.getDireccion()+"',CargoEmpleado='"+empleado.getCargo()+
                        "',Empleado_cel="+empleado.getCel()+",Usuario='"+empleado.getUsuario()+"',Clave='"+empleado.getClave()+"' Where Empleado_Cc="+empleado.getCc());
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void Insertar(Empleado empleado) {
                
        try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("INSERT INTO empleado VALUES ("+empleado.getId()+","+empleado.getCc()+",'"+empleado.getNombre()+"','"+empleado.getApellido()+"','"+empleado.getDireccion()+"',"+empleado.getCargo()+
                        ","+empleado.getCel()+",'"+empleado.getUsuario()+"','"+empleado.getClave()+"')");
        }
        catch(Exception e){
            e.printStackTrace();
        }    }

    @Override
    public void Eliminar(int cc) {
      
        try {
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("DELETE FROM empleado WHERE Empleado_Cc="+cc);
        } catch (Exception e) {
            e.printStackTrace();
        }  

    }

    @Override
    public Empleado getEmpleadoUsarioClave(String usuario, String clave) {
        Empleado empleado = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM empleado where Usuario ='"+usuario+"' and Clave ='"+clave+"' ");
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                empleado = new Empleado();
                empleado.setId(rs.getInt("EmpleadoID"));
                empleado.setCc(rs.getInt("Empleado_Cc"));
                empleado.setNombre(rs.getString("Empleado_nom"));
                empleado.setApellido(rs.getString("Empleado_ape"));
                empleado.setDireccion(rs.getString("Empleado_direc"));
                empleado.setCargo(rs.getInt("CargoEmpleado"));
                empleado.setCel(rs.getInt("Empleado_cel"));
                empleado.setUsuario(rs.getString("Usuario"));
                empleado.setClave(rs.getString("Clave"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return empleado;
    }
    
}
