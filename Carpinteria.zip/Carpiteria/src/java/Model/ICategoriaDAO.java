/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.List;

/**
 *
 * @author bryan
 */
public interface ICategoriaDAO {
     public List<Categoria> Listar();
     public Categoria getCategoria (int id);
     public void Guardar(Categoria categoria);
     public void Insertar(Categoria categoria);
     public void Eliminar (int id);
}
