/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Setting.ConnectionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author bryan
 */
public class CategoriaDAO implements ICategoriaDAO{
        private Connection conn;

    public Connection getConnection() {
        if(conn==null){
            conn = new ConnectionDB().getConnection();
        }
        return conn;
    }

    public void setConnetion(Connection conn) {
        this.conn = conn;
    }
    
    public void CloseConnection(){
        try{
            getConnection().close();
            conn=null;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public List<Categoria> Listar() {
        List<Categoria> lista= new ArrayList<Categoria>();
        try{
        Statement st = getConnection().createStatement();
        ResultSet rs= st.executeQuery("SELECT * FROM categoria");
        while(rs.next()){
            Categoria categoria = new Categoria();
                categoria.setId(rs.getInt("CategoriaID"));
                categoria.setNombre(rs.getString("Categoria_nom"));
                categoria.setDescripcion(rs.getString("Categoria_Descripcion"));
        lista.add(categoria);}
        } catch(Exception e){
                e.printStackTrace();
                }
        return lista;  
    }


    @Override
    public Categoria getCategoria(int id) {
      Categoria categoria = null;
        try {
            PreparedStatement stm = getConnection().prepareStatement(
                    "SELECT * FROM categoria where CategoriaID = ? ");
            stm.setInt(1, id);
            ResultSet rs = stm.executeQuery();
            if (rs.next()) {
                categoria = new Categoria();
                categoria.setId(rs.getInt("CategoriaID"));
                categoria.setNombre(rs.getString("Categoria_nom"));
                categoria.setDescripcion(rs.getString("Categoria_Descripcion"));
            }
            stm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return categoria;  

    }

    @Override
    public void Guardar(Categoria categoria) {
               try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("UPDATE categoria set Categoria_nom='"+categoria.getNombre()+"',Categoria_Descripcion='"+categoria.getDescripcion()+
                        "' Where CategoriaID="+categoria.getId());
        }
        catch(Exception e){
            e.printStackTrace();
        }    

    }

    @Override
    public void Insertar(Categoria categoria) {
       try{
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("INSERT INTO categoria  VALUES ("+categoria.getId()+",'"+categoria.getNombre()+"','"+categoria.getDescripcion()+"')");
        }
        catch(Exception e){
            e.printStackTrace();
        } 

    }

    @Override
    public void Eliminar(int id) {
                try {
            Statement stm = getConnection().createStatement();
                stm.executeUpdate("DELETE FROM categoria WHERE CategoriaID="+id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
