/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Categoria;
import Model.CategoriaDAO;
import Model.ICategoriaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "crear/categoria", urlPatterns = {"/crear/categoria"})
public class CrearCategoria extends HttpServlet {
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Registrar Categoria");
        request.setAttribute("titulo2","Registro de Categorias");
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/RegistroCategoria.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String id          = request.getParameter("id");
        String nombre      = request.getParameter("nombre");
        String descripcion       = request.getParameter("descripcion");
        Categoria categoria = new Categoria(Integer.parseInt(id),nombre,descripcion);
        ICategoriaDAO dao = new CategoriaDAO();
        dao.Insertar(categoria);
        
        Categoria car = new Categoria();
        car.setId(Integer.parseInt(id));
        car.setNombre(nombre);
        car.setDescripcion(descripcion);

        request.setAttribute("categorias",car);
        request.setAttribute("titulo1","Categoria Creada");
        request.setAttribute("titulo2","Datos de la categoria"+car.getNombre());
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/SalidaCategoria.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
