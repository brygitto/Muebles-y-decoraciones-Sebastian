/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.EmpleadoDAO;
import Model.IEmpleadoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "buscar/empleado", urlPatterns = {"/buscar/empleado"})
public class BuscarEmpleado extends HttpServlet {
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Buscar Empleado");
        request.setAttribute("titulo2","Buscador de Empleado");
        getServletContext().getRequestDispatcher("/WEB-INF/Buscar/BuscarEmpleado.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int  cc      = Integer.parseInt(request.getParameter("cc"));
        IEmpleadoDAO dao = new EmpleadoDAO();
        
     
            
            request.setAttribute("empleados",dao.getEmpleado(cc));
        getServletContext().getRequestDispatcher("/WEB-INF/Buscar/SalidaEmpleado.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
