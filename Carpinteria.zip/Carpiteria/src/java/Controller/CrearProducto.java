/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.IProductoDAO;
import Model.Producto;
import Model.ProductoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "CrearProducto", urlPatterns = {"/crear/producto"})
public class CrearProducto extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Registrar Productos");
        request.setAttribute("titulo2","Registro de Productos");
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/RegistroProducto.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String id          = request.getParameter("id");
        String categoria         = request.getParameter("categoria");
        String empleado      = request.getParameter("empleado");
        String nombre       = request.getParameter("nombre");
        String cant          = request.getParameter("cant");
        String precio = request.getParameter("precio");
        Producto producto = new Producto(Integer.parseInt(categoria),Integer.parseInt(empleado),nombre,Integer.parseInt(cant),Double.parseDouble(precio));
        IProductoDAO dao = new ProductoDAO();
        dao.Insertar(producto);
        
        Producto pro = new Producto();
        pro.setId(Integer.parseInt(id));
        pro.setCategoria(Integer.parseInt(categoria));
        pro.setEmpleado(Integer.parseInt(empleado));
        pro.setNombre(nombre);
        pro.setCant(Integer.parseInt(cant));
        pro.setPrecio(Double.parseDouble(precio));

        request.setAttribute("productos",pro);
        request.setAttribute("titulo1","Producto Creado");
        request.setAttribute("titulo2","Datos del Producto"+pro.getNombre());
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/SalidaProducto.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
