/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.IVentaDAO;
import Model.Venta;
import Model.VentaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "CrearVentas", urlPatterns = {"/crear/ventas"})
public class CrearVenta extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Registrar Ventas");
        request.setAttribute("titulo2","Registro de Ventas");
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/RegistroVenta.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String id          = request.getParameter("id");
        String cliente         = request.getParameter("cliente");
        String empleado      = request.getParameter("empleado");
        String producto       = request.getParameter("producto");
        String cant          = request.getParameter("cant");
        String precio = request.getParameter("precio");
        Venta venta = new Venta(Integer.parseInt(id),Integer.parseInt(cliente),Integer.parseInt(empleado),Integer.parseInt(producto),Integer.parseInt(cant),Double.parseDouble(precio));
        IVentaDAO dao = new VentaDAO();
        dao.Insertar(venta);
        
        Venta ven = new Venta();
        ven.setId(Integer.parseInt(id));
        ven.setCliente(Integer.parseInt(cliente));
        ven.setEmpleado(Integer.parseInt(empleado));
        ven.setProducto(Integer.parseInt(producto));
        ven.setCant(Integer.parseInt(cant));
        ven.setPrecio(Double.parseDouble(precio));

        request.setAttribute("ventas",ven);
        request.setAttribute("titulo1","Venta Creado");
        request.setAttribute("titulo2","Datos de la Venta");
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/SalidaVenta.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
