/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Empleado;
import Model.EmpleadoDAO;
import Model.IEmpleadoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "actualizar/empleado", urlPatterns = {"/actualizar/empleado"})
public class ActualizarEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Actualizar Empleado");
        request.setAttribute("titulo2","Actualizar datos del empleado");
        getServletContext().getRequestDispatcher("/WEB-INF/Actualizar/ActualizarEmpleado.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id          = request.getParameter("id");
        String cargo          = request.getParameter("cargo");
        String cc          = request.getParameter("cc");
        String nombre      = request.getParameter("nombre");
        String apellido       = request.getParameter("apellido");
        String direccion          = request.getParameter("direccion");
        String cel          = request.getParameter("cel");
        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");
        Empleado empleado = new Empleado(Integer.parseInt(cargo),Integer.parseInt(cc),nombre,apellido,direccion,Integer.parseInt(cel),usuario,clave);
        IEmpleadoDAO dao = new EmpleadoDAO();
        dao.Guardar(empleado);

        
        request.setAttribute("empleados",empleado);
        request.setAttribute("titulo1","Datos Actualizados");
        request.setAttribute("titulo2","Datos del Empleado "+empleado.getNombre());
        getServletContext().getRequestDispatcher("/WEB-INF/Actualizar/SalidaCliente.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
