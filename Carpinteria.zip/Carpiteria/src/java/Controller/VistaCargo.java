/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cargo;
import Model.CargoDAO;
import Model.ICargoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "cargo/listado", urlPatterns = {"/cargo/listado"})
public class VistaCargo extends HttpServlet {

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            ICargoDAO dao = new CargoDAO();
            List<Cargo> lista = dao.Listar();
            
            request.setAttribute("cargos",lista);
            request.setAttribute("titulo","Listado de Cargos");
            request.getRequestDispatcher("/WEB-INF/Vistas/cargos.jsp").forward(request, response);
    }
}