/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Empleado;
import Model.EmpleadoDAO;
import Model.IEmpleadoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "crear/empleado", urlPatterns = {"/crear/empleado"})
public class CrearEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Registrar Empleado");
        request.setAttribute("titulo2","Registro de Empleado");
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/RegistroEmpleado.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String id          = request.getParameter("id");
        String cargo          = request.getParameter("cargo");
        String cc          = request.getParameter("cc");
        String nombre      = request.getParameter("nombre");
        String apellido       = request.getParameter("apellido");
        String direccion          = request.getParameter("direccion");
        String cel          = request.getParameter("cel");
        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");
        Empleado empleado = new Empleado(Integer.parseInt(id),Integer.parseInt(cargo),Integer.parseInt(cc),nombre,apellido,direccion,Integer.parseInt(cel),usuario,clave);
        IEmpleadoDAO dao = new EmpleadoDAO();
        dao.Insertar(empleado);
        
        Empleado emp = new Empleado();
        emp.setId(Integer.parseInt(id));
        emp.setCargo(Integer.parseInt(cargo));
        emp.setCc(Integer.parseInt(cc));
        emp.setNombre(nombre);
        emp.setApellido(apellido);
        emp.setDireccion(direccion);
        emp.setCel(Integer.parseInt(cel));
        emp.setUsuario(usuario);
        emp.setClave(clave);

        request.setAttribute("empleados",emp);
        request.setAttribute("titulo1","Empleado Creado");
        request.setAttribute("titulo2","Datos del Empleado "+emp.getNombre());
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/SalidaEmpleado.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
