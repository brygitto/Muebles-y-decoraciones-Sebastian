/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cliente;
import Model.ClienteDAO;
import Model.IClienteDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "CrearCliente", urlPatterns = {"/crear/cliente"})
public class CrearCliente extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1","Registrar Clientes");
        request.setAttribute("titulo2","Registro de clientes");
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/RegistroCliente.jsp").forward(request, response);
    }

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String id          = request.getParameter("id");
        String cc          = request.getParameter("cc");
        String nombre      = request.getParameter("nombre");
        String apellido       = request.getParameter("apellido");
        String direccion          = request.getParameter("direccion");
        String correo = request.getParameter("correo");
        String cel          = request.getParameter("cel");
        Cliente cliente = new Cliente(Integer.parseInt(id),Integer.parseInt(cc),nombre,apellido,direccion,correo,Integer.parseInt(cel));
        IClienteDAO dao = new ClienteDAO();
        dao.Insertar(cliente);
        
        Cliente cli = new Cliente();
        cli.setId(Integer.parseInt(id));
        cli.setCc(Integer.parseInt(cc));
        cli.setNombre(nombre);
        cli.setApellido(apellido);
        cli.setDireccion(direccion);
        cli.setCorreo(correo);
        cli.setCel(Integer.parseInt(cel));

        request.setAttribute("cuenta",cli);
        request.setAttribute("titulo1","Cliente Creado");
        request.setAttribute("titulo2","Datos del Cliente"+cli.getNombre());
        getServletContext().getRequestDispatcher("/WEB-INF/Crear/SalidaCliente.jsp").forward(request, response);
        
        

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
