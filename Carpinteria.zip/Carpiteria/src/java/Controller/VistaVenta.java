/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.IVentaDAO;
import Model.Venta;
import Model.VentaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "/ventas/listado", urlPatterns = {"/ventas/listado"})
public class VistaVenta extends HttpServlet {

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            IVentaDAO dao = new VentaDAO();
            List<Venta> lista = dao.Listar();
            
            request.setAttribute("ventas",lista);
            request.setAttribute("titulo","Listado de Ventas");
            request.getRequestDispatcher("/WEB-INF/Vistas/ventas.jsp").forward(request, response);
    }
}