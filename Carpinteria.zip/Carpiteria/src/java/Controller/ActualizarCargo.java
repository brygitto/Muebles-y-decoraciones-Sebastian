/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cargo;
import Model.CargoDAO;
import Model.ICargoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "actualizar/cargo ", urlPatterns = {"/actualizar/cargo"})
public class ActualizarCargo extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("titulo1", "Actualizar Cargo");
        request.setAttribute("titulo2", "Actualizar datos del Cargo");
        getServletContext().getRequestDispatcher("/WEB-INF/Actualizar/ActualizarCargo.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        Cargo cargo = new Cargo(Integer.parseInt(id), nombre, descripcion);
        ICargoDAO dao = new CargoDAO();
        dao.Guardar(cargo);

        request.setAttribute("cargos", cargo);
        request.setAttribute("titulo1", "Cargo Actualizado");
        request.setAttribute("titulo2", "Datos del Cargo" + cargo.getNombre());
        getServletContext().getRequestDispatcher("/WEB-INF/Actualizar/SalidaCargo.jsp").forward(request, response);

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
