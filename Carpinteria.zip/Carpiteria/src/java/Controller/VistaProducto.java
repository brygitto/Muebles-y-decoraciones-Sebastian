/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;


import Model.IProductoDAO;
import Model.Producto;
import Model.ProductoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "/producto/listado", urlPatterns = {"/producto/listado"})
public class VistaProducto extends HttpServlet {

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            IProductoDAO dao = new ProductoDAO();
            List<Producto> lista = dao.Listar();
            
            request.setAttribute("productos",lista);
            request.setAttribute("titulo","Listado de Productos");
            request.getRequestDispatcher("/WEB-INF/Vistas/productos.jsp").forward(request, response);
    }
}