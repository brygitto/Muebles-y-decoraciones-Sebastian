/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Empleado;
import Model.EmpleadoDAO;
import Model.IEmpleadoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author bryan
 */
@WebServlet(name = "validar-usuario", urlPatterns = {"/validar-usuario"})
public class ControladorIngreso extends HttpServlet {
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        getServletContext().getRequestDispatcher("index.jsp").forward(request, response);
    }
    
        @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String usuario = request.getParameter("usuario");
        String clave = request.getParameter("clave");
        IEmpleadoDAO dao = new EmpleadoDAO();
        Empleado emp = dao.getEmpleadoUsarioClave(usuario, clave);
        
        if(emp != null){
            
            switch(emp.getCargo()){
                case 1:getServletContext().getRequestDispatcher("/Admin/MenuAdmin.html").forward(request, response); break;
                case 2:getServletContext().getRequestDispatcher("/Visualize/MenuVisualize.html").forward(request, response);break;
                case 3:getServletContext().getRequestDispatcher("/Visualize/MenuVisualize.html").forward(request, response);break;
                case 4:getServletContext().getRequestDispatcher("/Add/MenuAdd.html").forward(request, response);break;
                default:getServletContext().getRequestDispatcher("/index.html").forward(request, response);
            } 
            
        }
        
        else{
            getServletContext().getRequestDispatcher("/mensaje.jsp").forward(request, response);
        }
        
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
