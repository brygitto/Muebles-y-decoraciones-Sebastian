/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Empleado;
import Model.EmpleadoDAO;
import Model.IEmpleadoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bryan
 */
@WebServlet(name = "empleado/listado", urlPatterns = {"/empleado/listado"})
public class VistaEmpleado extends HttpServlet {

  
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            IEmpleadoDAO dao = new EmpleadoDAO();
            List<Empleado> lista = dao.Listar();
            
            request.setAttribute("empleados",lista);
            request.setAttribute("titulo","Listado de Empleados");
            request.getRequestDispatcher("/WEB-INF/Vistas/empleados.jsp").forward(request, response);
    }
}
