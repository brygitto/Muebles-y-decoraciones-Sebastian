/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Setting;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author bryan
 */
public class ConnectionDB {
    private Connection conn;
    private String user="root";
    private String password="YDKqiy77233";
    private String url="jdbc:mysql://node103390-mydsebastian.jelastic.saveincloud.net:3306/Carpinter";
    private String driverClass="com.mysql.jdbc.Driver";

    public ConnectionDB(String user,String password,String url,String driverClass) {
        this.user=user;
        this.password=password;
        this.url=url;
        this.driverClass=driverClass;
        conectar();
    }

    public ConnectionDB() {
        conectar();
    }
    
    private void conectar(){
        try{
            Class.forName(driverClass);
            conn= DriverManager.getConnection(url,user,password);
        }catch(ClassNotFoundException e){
            System.out.println("ERROR"+e);
        }catch(SQLException e){
            System.out.println("ERROR"+e);}
        
    }
    
    public Connection getConnection(){
           return conn;
    }
}

