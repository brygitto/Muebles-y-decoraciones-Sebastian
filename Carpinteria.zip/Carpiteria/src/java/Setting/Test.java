/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Setting;

import Model.Cliente;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author bryan
 */
public class Test {
    public static void main(String[] args) throws Exception{
        
        try{
            ConnectionDB conn = new ConnectionDB("root","ITFhlp40167","jdbc:mysql://node103385-env-0351125.jelastic.saveincloud.net:3306/Carpinter","com.mysql.jdbc.Driver");
            Statement st = conn.getConnection().createStatement();
            ResultSet rs= st.executeQuery("SELECT * FROM CLIENTE");
            while(rs.next()){
                 System.out.println(rs.getInt("ClienteID")+" - "+
                                    rs.getString("Cliente_Cc")+" - "+
                                    rs.getString("Cliente_nom")+" - "+
                                    rs.getString("Cliente_ape")+" - "+
                                    rs.getString("Cliente_direc")+" - "+
                                    rs.getString("Cliente_correo")+" - "+
                                    rs.getString("Cliente_cel"));
            }
        }catch(Exception e){
            System.out.println("ERROR"+e);
        }
    }
}
